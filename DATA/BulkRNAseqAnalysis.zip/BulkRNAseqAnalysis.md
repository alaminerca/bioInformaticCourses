# This is the first step in our analysis of a real-life dataset.

We are going to re-analyse the dataset presented in the paper "Single-cell transcriptomics identifies an effectorness gradient shaping the response of CD4+ T cells to cytokines" by Cano-Gamez et al. (https://www.nature.com/articles/s41467-020-15543-y). In summary, they have studied the response of CD4+ T cells in response to different cytokines forming an effectorness gradient. In this lab we will analyze bulk RNA-seq data to elucidate the expression patterns of naive CD4+ T cells showing the Th2 phenotype as compared to the Th0 phenotype.


```R
# load required packages
require(ggplot2, quietly = TRUE)
require(DESeq2, quietly = TRUE)
require(EnhancedVolcano, quietly = TRUE)
require(testthat, quietly = TRUE)
```

    Warning message:
    “replacing previous import ‘ellipsis::check_dots_unnamed’ by ‘rlang::check_dots_unnamed’ when loading ‘tibble’”
    Warning message:
    “replacing previous import ‘ellipsis::check_dots_used’ by ‘rlang::check_dots_used’ when loading ‘tibble’”
    Warning message:
    “replacing previous import ‘ellipsis::check_dots_empty’ by ‘rlang::check_dots_empty’ when loading ‘tibble’”
    Registered S3 methods overwritten by 'tibble':
      method     from  
      format.tbl pillar
      print.tbl  pillar
    
    
    Attaching package: ‘BiocGenerics’
    
    
    The following objects are masked from ‘package:parallel’:
    
        clusterApply, clusterApplyLB, clusterCall, clusterEvalQ,
        clusterExport, clusterMap, parApply, parCapply, parLapply,
        parLapplyLB, parRapply, parSapply, parSapplyLB
    
    
    The following objects are masked from ‘package:stats’:
    
        IQR, mad, sd, var, xtabs
    
    
    The following objects are masked from ‘package:base’:
    
        anyDuplicated, append, as.data.frame, basename, cbind, colnames,
        dirname, do.call, duplicated, eval, evalq, Filter, Find, get, grep,
        grepl, intersect, is.unsorted, lapply, Map, mapply, match, mget,
        order, paste, pmax, pmax.int, pmin, pmin.int, Position, rank,
        rbind, Reduce, rownames, sapply, setdiff, sort, table, tapply,
        union, unique, unsplit, which, which.max, which.min
    
    
    
    Attaching package: ‘S4Vectors’
    
    
    The following object is masked from ‘package:base’:
    
        expand.grid
    
    
    Welcome to Bioconductor
    
        Vignettes contain introductory material; view with
        'browseVignettes()'. To cite Bioconductor, see
        'citation("Biobase")', and for packages 'citation("pkgname")'.
    
    
    
    Attaching package: ‘matrixStats’
    
    
    The following objects are masked from ‘package:Biobase’:
    
        anyMissing, rowMedians
    
    
    
    Attaching package: ‘DelayedArray’
    
    
    The following objects are masked from ‘package:matrixStats’:
    
        colMaxs, colMins, colRanges, rowMaxs, rowMins, rowRanges
    
    
    The following objects are masked from ‘package:base’:
    
        aperm, apply, rowsum
    
    



```R
# loading phenotype ananotation data located in the following file:
# ./data/NCOMMS-19-7936188_bulk_RNAseq_raw_counts.txt.gz

# ge_matrix <- 
ge_matrix <- read.delim(
  "./data/NCOMMS-19-7936188_bulk_RNAseq_raw_counts.txt.gz", 
  header = TRUE, 
  row.names = 1
)



# your code here


dim(ge_matrix)

```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>58051</li><li>94</li></ol>




```R

```


```R
# loading phenotype annotation data located in the following file:
# ./data/NCOMMS-19-7936188_bulk_RNAseq_metadata.txt.gz

# pheno_matrix <- 

# Assign the column "sample_id" as rownames of the pheno_matrix data.frame
pheno_matrix <- read.delim(
  "./data/NCOMMS-19-7936188_bulk_RNAseq_metadata.txt.gz", 
  header = TRUE
)

rownames(pheno_matrix) <- pheno_matrix$sample_id
pheno_matrix$sample_id <- NULL

# your code here


dim(pheno_matrix)
head(pheno_matrix)

```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>94</li><li>9</li></ol>




<table>
<caption>A data.frame: 6 × 9</caption>
<thead>
	<tr><th></th><th scope=col>cell_type</th><th scope=col>cytokine_condition</th><th scope=col>stimulation_time</th><th scope=col>donor_id</th><th scope=col>sex</th><th scope=col>age</th><th scope=col>sequencing_batch</th><th scope=col>cell_culture_batch</th><th scope=col>rna_integrity_number</th></tr>
	<tr><th></th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>I0712</th><td>CD4_Naive </td><td>IFNB   </td><td>16h</td><td>257</td><td>Male</td><td>38</td><td>1</td><td>3</td><td> 9.5</td></tr>
	<tr><th scope=row>I0713</th><td>CD4_Naive </td><td>Th17   </td><td>16h</td><td>254</td><td>Male</td><td>58</td><td>1</td><td>3</td><td> 9.3</td></tr>
	<tr><th scope=row>I0717</th><td>CD4_Memory</td><td>Resting</td><td>5d </td><td>265</td><td>Male</td><td>59</td><td>1</td><td>4</td><td> 9.7</td></tr>
	<tr><th scope=row>I0721</th><td>CD4_Naive </td><td>Th2    </td><td>5d </td><td>257</td><td>Male</td><td>38</td><td>1</td><td>3</td><td>10.0</td></tr>
	<tr><th scope=row>I0726</th><td>CD4_Memory</td><td>Th17   </td><td>5d </td><td>264</td><td>Male</td><td>27</td><td>1</td><td>4</td><td> 9.9</td></tr>
	<tr><th scope=row>I0731</th><td>CD4_Naive </td><td>Th0    </td><td>16h</td><td>257</td><td>Male</td><td>38</td><td>1</td><td>3</td><td> 9.4</td></tr>
</tbody>
</table>




```R

```

## We start by performing a DEG analysis for naive CD4+ cells


```R
# Create an index "toSelect", selecting samples (rows) from the phenotype matrix "pheno_matrix" where column
# "stimulation_time" equals "5d", the cell phenotype ("cytokine_condition") equals either 'Th2' or'Th0', and 
# the sample cell type "cell_type" is "CD4_Naive"

# toSelect <-
toSelect <- pheno_matrix$stimulation_time == "5d" & 
            pheno_matrix$cytokine_condition %in% c("Th2", "Th0") & 
            pheno_matrix$cell_type == "CD4_Naive"

# your code here

# We use this index now to subset our samples before doing the differential 
# expression analysis.
pheno_matrix_subset <- pheno_matrix[toSelect, ]
ge_matrix_subset <- ge_matrix[ , toSelect]

dim(pheno_matrix_subset)
dim(ge_matrix_subset)
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>9</li><li>9</li></ol>




<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>58051</li><li>9</li></ol>




```R

```


```R
# Now we have to generate the DESeq2 dataset using the phenotype matrix subset (ge_matrix_subset) 
# and count matrix subset (pheno_matrix_subset) that we have created above. Furthermore, we need to
# set the design formula to measure the effect of the variable "cytokine_condition".
# Remember that we have selected the samples to have either cytokine_condition, i.e. phenotype
# Th0 or Th2, by setting the design to column cytokine_condition we set our DESeq up to measure 
# the differtially expressed genes (DEGs) between these two phenotypes.

# dds <- DESeqDataSetFromMatrix(...)

dds <- DESeqDataSetFromMatrix(
  countData = ge_matrix_subset,
  colData = pheno_matrix_subset,
  design = ~ cytokine_condition
)
# your code here


# apply minimal filtering, keeping only genes (rows) with at least 10 counts between all retained samples
keep <- rowSums(counts(dds)) >= 10
dds <- dds[keep,]
dds
```

    factor levels were dropped which had no samples
    



    class: DESeqDataSet 
    dim: 27516 9 
    metadata(1): version
    assays(1): counts
    rownames(27516): ENSG00000227232 ENSG00000278267 ... ENSG00000271254
      ENSG00000275405
    rowData names(0):
    colnames(9): I0721 I0732 ... I0872 I0877
    colData names(9): cell_type cytokine_condition ... cell_culture_batch
      rna_integrity_number



```R

```


```R
# This DESeq2 dataset can now be used to plot a principle component analysis,
# e.g. to inspect whether the samples separate according to the applied treatment.

plotPCA(rlog(dds), intgroup = 'cytokine_condition')
```


![png](output_11_0.png)



```R
# However, we dont want to see a separation of samples by by sequencing batch as this would
# constitute a confounding factor. Let's check that

plotPCA(rlog(dds), intgroup = 'sequencing_batch')
```


![png](output_12_0.png)



```R
# Now we can run the differential expression analysis with the DESeq command
dds <- DESeq(object = dds)
# The result of the analysis is then accessible via the "results" command:
DESeqRes <- results(dds)

# We can also discard genes with adjusted P-values of NA, which DESeq2 assignes when certain quality control
# criteria are not met, such as low counts
DESeqRes <- DESeqRes[!is.na(DESeqRes$padj),]
```

    estimating size factors
    
    estimating dispersions
    
    gene-wise dispersion estimates
    
    mean-dispersion relationship
    
    final dispersion estimates
    
    fitting model and testing
    



```R
# Now you can inspect the result object. Order the results table by adjusted p-value (column "padj") in
# ascending order, use the function "order"

# DESeqRes <- ...
DESeqResSorted <- DESeqRes[order(DESeqRes$padj), ]
# your code here


# Inspect the top genes
head(DESeqResSorted)
```


    log2 fold change (MLE): cytokine condition Th2 vs Th0 
    Wald test p-value: cytokine condition Th2 vs Th0 
    DataFrame with 6 rows and 6 columns
                            baseMean    log2FoldChange              lfcSE
                           <numeric>         <numeric>          <numeric>
    ENSG00000189221 1692.64307218668  7.57998568070103  0.266534927907165
    ENSG00000050405 11267.3060671304  2.83111088164711 0.0999389764174932
    ENSG00000204177 286.369283171735  4.51111090333947  0.184418070081082
    ENSG00000125901 2953.85686373281  2.45282051458582  0.105129761514081
    ENSG00000033327 2579.11095222412  1.45913529084305 0.0644535212334884
    ENSG00000225783 5977.30272895174 -1.85365901721805 0.0865863801153483
                                 stat                pvalue                  padj
                            <numeric>             <numeric>             <numeric>
    ENSG00000189221  28.4389957452074  6.6666785849836e-178  1.4430025797197e-173
    ENSG00000050405  28.3283958184663 1.54507623528388e-176 1.67215875563598e-172
    ENSG00000204177  24.4613280106234 3.81293472030356e-132 2.75103240069902e-128
    ENSG00000125901  23.3313619213079 2.13095047088078e-120 1.15311057355536e-116
    ENSG00000033327  22.6385659451747 1.80831133345631e-113 7.82817976253236e-110
    ENSG00000225783 -21.4082054792988 1.12044697243919e-101  4.04201245307439e-98



```R

```


```R
# Now we can filter out the statistically significant differentially expressed genes.
# Apply two criteria to create an index, column padj <= 0.01 and the 
# absolute value of column log2FoldChange > 1, hint: use the function abs

# idx <- ...
idx <- which(DESeqResSorted$padj <= 0.01 & abs(DESeqResSorted$log2FoldChange) > 1)
# your code here


cat("number of significant DEGs:" , length(idx), "\n")

# And our 10 genes with the stronges response are:
DESeqResSorted[head(idx, 10),]
```

    number of significant DEGs: 939 



    log2 fold change (MLE): cytokine condition Th2 vs Th0 
    Wald test p-value: cytokine condition Th2 vs Th0 
    DataFrame with 10 rows and 6 columns
                            baseMean    log2FoldChange              lfcSE
                           <numeric>         <numeric>          <numeric>
    ENSG00000189221 1692.64307218668  7.57998568070103  0.266534927907165
    ENSG00000050405 11267.3060671304  2.83111088164711 0.0999389764174932
    ENSG00000204177 286.369283171735  4.51111090333947  0.184418070081082
    ENSG00000125901 2953.85686373281  2.45282051458582  0.105129761514081
    ENSG00000033327 2579.11095222412  1.45913529084305 0.0644535212334884
    ENSG00000225783 5977.30272895174 -1.85365901721805 0.0865863801153483
    ENSG00000154096 468.212096629712  8.22451262562469  0.390177224027555
    ENSG00000131016 1894.13557012306    3.547024192544  0.169828853168658
    ENSG00000197594  310.18407396876  7.46495658643132  0.369328300836003
    ENSG00000152990  1201.4968147833  2.22187765652959   0.11364098843249
                                 stat                pvalue                  padj
                            <numeric>             <numeric>             <numeric>
    ENSG00000189221  28.4389957452074  6.6666785849836e-178  1.4430025797197e-173
    ENSG00000050405  28.3283958184663 1.54507623528388e-176 1.67215875563598e-172
    ENSG00000204177  24.4613280106234 3.81293472030356e-132 2.75103240069902e-128
    ENSG00000125901  23.3313619213079 2.13095047088078e-120 1.15311057355536e-116
    ENSG00000033327  22.6385659451747 1.80831133345631e-113 7.82817976253236e-110
    ENSG00000225783 -21.4082054792988 1.12044697243919e-101  4.04201245307439e-98
    ENSG00000154096  21.0789152189054  1.24197517308373e-98  3.84036466019963e-95
    ENSG00000131016  20.8858749639051  7.19742729303332e-97  1.94735392197133e-93
    ENSG00000197594  20.2122517270781  7.63826329496883e-91     1.83700232244e-87
    ENSG00000152990  19.5517276572223  3.98784763925221e-85   8.6316962151614e-82



```R

```


```R
# Finally, a volcano plot is a good way of visualizing the result of the differential expression analysis,
# including the log-fold-change and P-value of the considered genes.

EnhancedVolcano(DESeqRes, 
                lab = rownames(DESeqRes), 
                x = 'log2FoldChange', y = 'padj', 
                subtitle = 'Th2 vs Th0', 
                labSize = 3, 
                pCutoff = 0.01,
                FCcutoff = 1,
                drawConnectors = FALSE)
```


![png](output_18_0.png)


## Now we repeat the DEG analysis for memory cells


```R
# Again, we have to create an index "toSelect", selecting samples (rows) from the phenotype 
# matrix "pheno_matrix" where column "stimulation_time" equals "5d", the cell phenotype 
# ("cytokine_condition") equals either 'Th2' or'Th0', and the sample cell type "cell_type" is "CD4_Memory"

# toSelect <-
toSelect <- pheno_matrix$stimulation_time == "5d" & 
            pheno_matrix$cytokine_condition %in% c("Th2", "Th0") & 
            pheno_matrix$cell_type == "CD4_Memory"

# your code here


# We use this index now to subset our samples before doing the differential 
# expression analysis.
pheno_matrix_subset <- pheno_matrix[toSelect, ]
ge_matrix_subset <- ge_matrix[ , toSelect]

dim(pheno_matrix_subset)
dim(ge_matrix_subset)
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>9</li><li>9</li></ol>




<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>58051</li><li>9</li></ol>




```R

```


```R
# Generate the DESeq2 dataset using the phenotype matrix subset and count matrix subset. The 
# design formula to is still "cytokine_condition".

# ddsMem <- DESeqDataSetFromMatrix(...)
ddsMem <- DESeqDataSetFromMatrix(
  countData = ge_matrix_subset,
  colData = pheno_matrix_subset,
  design = ~ cytokine_condition
)
# your code here


# apply minimal filtering, keeping only genes (rows) with at least 10 counts between all retained samples
keep <- rowSums(counts(ddsMem)) >= 10
ddsMem <- ddsMem[keep,]
ddsMem
```

    factor levels were dropped which had no samples
    



    class: DESeqDataSet 
    dim: 26656 9 
    metadata(1): version
    assays(1): counts
    rownames(26656): ENSG00000227232 ENSG00000278267 ... ENSG00000271254
      ENSG00000275405
    rowData names(0):
    colnames(9): I0736 I0749 ... I0867 I0874
    colData names(9): cell_type cytokine_condition ... cell_culture_batch
      rna_integrity_number



```R

```


```R
# This DESeq2 dataset can now be used to plot a principle component analysis,
# e.g. to inspect whether the samples separate according to the applied treatment.

plotPCA(rlog(ddsMem), intgroup = 'cytokine_condition')
```


![png](output_24_0.png)



```R
# However, we dont want to see a separation of samples by by sequencing batch as this would
# constitute a confounding factor. Let's check that

plotPCA(rlog(ddsMem), intgroup = 'sequencing_batch')
```


![png](output_25_0.png)



```R
# Now we can run the differential expression analysis with the DESeq command
ddsMem <- DESeq(object = ddsMem)
# The result of the analysis is then accessible via the "results" command:
DESeqMemRes <- results(ddsMem)

# We can also discard genes with adjusted P-values of NA, which DESeq2 assignes when certain quality control
# criteria are not met, such as low counts
DESeqMemRes <- DESeqMemRes[!is.na(DESeqMemRes$padj),]
```

    estimating size factors
    
    estimating dispersions
    
    gene-wise dispersion estimates
    
    mean-dispersion relationship
    
    final dispersion estimates
    
    fitting model and testing
    



```R
# Now you can inspect the result object. Order the results table by adjusted p-value (column "padj") in
# ascending order, use the function "order"

# DESeqRes <- ...
DESeqMemRes <- results(ddsMem)
DESeqMemRes <- DESeqMemRes[!is.na(DESeqMemRes$padj), ]
DESeqMemResSorted <- DESeqMemRes[order(DESeqMemRes$padj), ]
# your code here


# Inspect the top genes
head(DESeqMemResSorted)
```


    log2 fold change (MLE): cytokine condition Th2 vs Th0 
    Wald test p-value: cytokine condition Th2 vs Th0 
    DataFrame with 6 rows and 6 columns
                            baseMean     log2FoldChange              lfcSE
                           <numeric>          <numeric>          <numeric>
    ENSG00000145839 1501.35903253062  0.980118845489905 0.0940843726535917
    ENSG00000102970 202.855469985311   1.56694940179679  0.176911307986771
    ENSG00000049249 2356.48879590186  0.484300839985658 0.0661352937482808
    ENSG00000166949 2947.20477967503 -0.754552787697488  0.112801757908666
    ENSG00000023171 3275.60681781047 -0.523241831319512 0.0790959717330436
    ENSG00000159216 6041.29248909045  0.420910480789458 0.0651092620075711
                                 stat               pvalue                 padj
                            <numeric>            <numeric>            <numeric>
    ENSG00000145839  10.4174457228789 2.06422528710071e-25 4.96900311110882e-21
    ENSG00000102970   8.8572597174736 8.20053239753115e-19 9.87016079366849e-15
    ENSG00000049249  7.32288030395642 2.42704272321963e-13 1.94745908111143e-09
    ENSG00000166949 -6.68919351689928 2.24403826138494e-11 1.35046222570145e-07
    ENSG00000023171 -6.61527786883385   3.708544720753e-11 1.78544177035932e-07
    ENSG00000159216  6.46467903046594 1.01514047552831e-10 4.07274358781958e-07



```R

```


```R
# Now we can filter out the statistically significant differentially expressed genes.
# Apply two criteria to create an index, column padj <= 0.01 and the 
# absolute value of column log2FoldChange > 1, hint: use the function abs

# idx <- ...

# your code here


cat("number of significant DEGs:" , length(idx), "\n")

# And our 10 genes with the stronges response are:
DESeqMemResSorted[head(idx, 10),]
```


```R

```


```R
# Finally, a volcano plot is a good way of visualizing the result of the differential expression analysis,
# including the log-fold-change and P-value of the considered genes.

EnhancedVolcano(DESeqMemRes, 
                lab = rownames(DESeqMemRes), 
                x = 'log2FoldChange', y = 'padj', 
                subtitle = 'Memory cells - Th2 vs Th0', 
                labSize = 3, 
                pCutoff = 0.01,
                FCcutoff = 1,
                drawConnectors = FALSE)
```


![png](output_31_0.png)


## Compare lists of DEGs to find shared and unique genes between naive and memory CD4+ cells


```R
# Now we can make two lists of DEGs for naive and memory cells, wbich we can then compare.
# Apply the same two criteria to create an index, column padj <= 0.01 and the 
# absolute value of column log2FoldChange > 1, to both DESeq2 result tables.
# Finally, store the shared DEGs between cell types in the list "sharedDEGs",
# "naiveSpecificDEGs" and "memSpecificDEGs". Hint: the functions "intersect" and "setdiff" come in handy here

# sharedDEGs <- ...
# naiveSpecificDEGs <- ...
# memSpecificDEGs <- ...

# your code here


# And our 10 genes with the stronges response are:
cat("Number of shared DEGs between memory and naive CD4+ cells:" , length(sharedDEGs), "\n")
cat("Number of DEGs specific to naive CD4+ cells:" , length(naiveSpecificDEGs), "\n")
cat("Number of DEGs specific to memory CD4+ cells:" , length(memSpecificDEGs), "\n")
```


    Error in cat("Number of shared DEGs between memory and naive CD4+ cells:", : object 'sharedDEGs' not found
    Traceback:


    1. cat("Number of shared DEGs between memory and naive CD4+ cells:", 
     .     length(sharedDEGs), "\n")



```R

```


```R

```
